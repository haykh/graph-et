from .typing import array_t
from .fmt import sizeof_fmt
