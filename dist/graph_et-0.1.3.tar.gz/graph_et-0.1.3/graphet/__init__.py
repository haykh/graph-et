__version__ = "0.1.3"

from .data import Data

__all__ = ["Data"]
