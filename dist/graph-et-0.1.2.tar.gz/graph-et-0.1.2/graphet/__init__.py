__version__ = "0.1.2"

from .data import Data

__all__ = ["Data"]
